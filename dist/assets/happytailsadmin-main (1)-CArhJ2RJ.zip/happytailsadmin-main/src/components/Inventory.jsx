import React, { useMemo, useState } from 'react';
import './Inventory.css';

const PRODUCT_TYPES = ['Pet Shop', 'Pet Menu'];

/**
 * @typedef {{ id: number, name: string, price: number }} ProductVariation
 * @typedef {{ id: number, productType: 'Pet Shop'|'Pet Menu', name: string, category: string, petType: string, price: number, stock: number|null, brand: string, description: string, image: string|null, variations: ProductVariation[] }} Product
 */

const initialProducts = /** @type {Product[]} */([
  {
    id: 1,
    productType: 'Pet Shop',
    name: 'JerHigh Dog Treats 70g',
    category: 'Pet Food & Treats',
    petType: 'Dogs',
    price: 119,
    stock: 150,
    brand: 'JerHigh',
    description: 'Premium treats for dogs.',
    image: null,
    variations: [
      { id: 1, name: 'Small', price: 119 },
      { id: 2, name: 'Large', price: 159 }
    ]
  },
  {
    id: 2,
    productType: 'Pet Shop',
    name: 'CatCare Cat Food 1kg',
    category: 'Pet Food & Treats',
    petType: 'Cats',
    price: 279,
    stock: 150,
    brand: 'CatCare',
    description: 'Nutritious cat food for all breeds.',
    image: null,
    variations: []
  },
  {
    id: 3,
    productType: 'Pet Menu',
    name: 'Chicken Rice Bowl',
    category: 'Pet Treats',
    petType: 'All Pets',
    price: 220,
    stock: null,
    brand: 'Happy Tails Kitchen',
    description: 'Freshly prepared chicken bowl for pets.',
    image: null,
    variations: [
      { id: 1, name: 'Regular', price: 220 },
      { id: 2, name: 'Large', price: 260 }
    ]
  }
]);

const baseFormState = {
  productType: 'Pet Shop',
  name: '',
  category: 'Pet Food & Treats',
  petType: 'All Pets',
  price: '',
  stock: '',
  brand: '',
  description: '',
  image: null,
  imageName: '',
  variations: []
};

function Inventory() {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTypeTab, setActiveTypeTab] = useState(/** @type {'Pet Shop'|'Pet Menu'} */('Pet Shop'));
  const [category, setCategory] = useState('All Categories');
  const [sortBy, setSortBy] = useState('name-asc');
  const [stockLevel, setStockLevel] = useState('All Stock Levels');
  const [selectedPetType, setSelectedPetType] = useState('All Pets');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(/** @type {Product|null} */(null));
  const [activeDropdown, setActiveDropdown] = useState(/** @type {number|null} */(null));

  const [products, setProducts] = useState(initialProducts);
  const [newProduct, setNewProduct] = useState(baseFormState);
  const [editForm, setEditForm] = useState(baseFormState);

  const categories = useMemo(() => {
    const items = products.filter((product) => product.productType === activeTypeTab);
    return ['All Categories', ...new Set(items.map((product) => product.category))];
  }, [products, activeTypeTab]);

  const petTypes = ['All Pets', 'Dogs', 'Cats'];
  const stockLevels = ['All Stock Levels', 'In Stock', 'Low Stock (≤10)', 'Out of Stock'];

  const getCategoryOptions = (productType) => (
    productType === 'Pet Menu'
      ? ['Frozen Treats', 'Pet Treats']
      : ['Pet Food & Treats', 'Health & Wellness', 'Litter & Toilet', 'Pet Accessories & Toys']
  );

  const handleImageUpload = (event, target) => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;

    const imageUrl = URL.createObjectURL(file);

    if (target === 'add') {
      setNewProduct((prev) => ({ ...prev, image: imageUrl, imageName: file.name }));
      return;
    }

    setEditForm((prev) => ({ ...prev, image: imageUrl, imageName: file.name }));
  };

  const handleVariationChange = (target, index, field, value) => {
    const updateVariations = (variations) => variations.map((variation, variationIndex) => (
      variationIndex === index ? { ...variation, [field]: value } : variation
    ));

    if (target === 'add') {
      setNewProduct((prev) => ({ ...prev, variations: updateVariations(prev.variations) }));
      return;
    }

    setEditForm((prev) => ({ ...prev, variations: updateVariations(prev.variations) }));
  };

  const handleAddVariation = (target) => {
    const newVariation = { id: Date.now(), name: '', price: '' };

    if (target === 'add') {
      setNewProduct((prev) => ({ ...prev, variations: [...prev.variations, newVariation] }));
      return;
    }

    setEditForm((prev) => ({ ...prev, variations: [...prev.variations, newVariation] }));
  };

  const handleDeleteVariation = (target, variationId) => {
    if (target === 'add') {
      setNewProduct((prev) => ({ ...prev, variations: prev.variations.filter((variation) => variation.id !== variationId) }));
      return;
    }

    setEditForm((prev) => ({ ...prev, variations: prev.variations.filter((variation) => variation.id !== variationId) }));
  };

  const handleInputChange = (event, target) => {
    const { name, value } = event.target;

    if (target === 'add') {
      setNewProduct((prev) => ({
        ...prev,
        [name]: value,
        ...(name === 'productType' ? { category: getCategoryOptions(value)[0], stock: value === 'Pet Menu' ? '' : prev.stock } : {})
      }));
      return;
    }

    setEditForm((prev) => ({
      ...prev,
      [name]: value,
      ...(name === 'productType' ? { category: getCategoryOptions(value)[0], stock: value === 'Pet Menu' ? '' : prev.stock } : {})
    }));
  };

  const handleAddProduct = (event) => {
    event.preventDefault();

    const productToAdd = {
      id: Date.now(),
      productType: newProduct.productType,
      name: newProduct.name,
      category: newProduct.category,
      petType: newProduct.petType,
      price: Number(newProduct.price),
      stock: newProduct.productType === 'Pet Menu' ? null : Number(newProduct.stock),
      brand: newProduct.brand,
      description: newProduct.description,
      image: newProduct.image,
      variations: newProduct.variations.filter((variation) => variation.name && variation.price).map((variation) => ({ ...variation, price: Number(variation.price) }))
    };

    setProducts((prev) => [...prev, productToAdd]);
    setNewProduct({ ...baseFormState, category: 'Pet Food & Treats' });
    setIsAddModalOpen(false);
  };

  const handleEditProduct = (product) => {
    setSelectedProduct(product);
    setEditForm({
      productType: product.productType,
      name: product.name,
      category: product.category,
      petType: product.petType,
      price: String(product.price),
      stock: product.stock === null ? '' : String(product.stock),
      brand: product.brand,
      description: product.description,
      image: product.image,
      imageName: '',
      variations: product.variations.map((variation) => ({ ...variation, price: String(variation.price) }))
    });
    setIsEditModalOpen(true);
    setActiveDropdown(null);
  };

  const handleSaveEdit = (event) => {
    event.preventDefault();
    if (!selectedProduct) return;

    const updatedProducts = products.map((product) => (
      product.id === selectedProduct.id
        ? {
            ...product,
            productType: editForm.productType,
            name: editForm.name,
            category: editForm.category,
            petType: editForm.petType,
            price: Number(editForm.price),
            stock: editForm.productType === 'Pet Menu' ? null : Number(editForm.stock),
            brand: editForm.brand,
            description: editForm.description,
            image: editForm.image,
            variations: editForm.variations.filter((variation) => variation.name && variation.price).map((variation) => ({ ...variation, price: Number(variation.price) }))
          }
        : product
    ));

    setProducts(updatedProducts);
    setIsEditModalOpen(false);
    setSelectedProduct(null);
  };

  const handleDeleteProduct = (productId) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      setProducts((prev) => prev.filter((product) => product.id !== productId));
    }
    setActiveDropdown(null);
  };

  const filteredProducts = products.filter((product) => {
    if (product.productType !== activeTypeTab) return false;

    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = category === 'All Categories' || product.category === category;
    const matchesPetType = selectedPetType === 'All Pets' || product.petType === selectedPetType;

    let matchesStock = true;
    if (activeTypeTab === 'Pet Shop') {
      if (stockLevel === 'In Stock') {
        matchesStock = (product.stock || 0) > 0;
      } else if (stockLevel === 'Low Stock (≤10)') {
        matchesStock = (product.stock || 0) <= 10 && (product.stock || 0) > 0;
      } else if (stockLevel === 'Out of Stock') {
        matchesStock = (product.stock || 0) === 0;
      }
    }

    return matchesSearch && matchesCategory && matchesPetType && matchesStock;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'name-asc': return a.name.localeCompare(b.name);
      case 'name-desc': return b.name.localeCompare(a.name);
      case 'price-asc': return a.price - b.price;
      case 'price-desc': return b.price - a.price;
      case 'stock-asc': return (a.stock || 0) - (b.stock || 0);
      case 'stock-desc': return (b.stock || 0) - (a.stock || 0);
      default: return 0;
    }
  });

  return (
    <div className="inventory-container">
      <div className="inventory-header">
        <h1>Inventory</h1>
        <p>Manage your products and stock.</p>
      </div>

      <div className="inventory-type-tabs">
        {PRODUCT_TYPES.map((type) => (
          <button
            key={type}
            type="button"
            className={`inventory-type-tab ${activeTypeTab === type ? 'active' : ''}`}
            onClick={() => {
              setActiveTypeTab(type);
              setCategory('All Categories');
            }}
          >
            {type}
          </button>
        ))}
      </div>

      <div className="inventory-filters">
        <input type="text" className="search-input" placeholder="Search items..." value={searchTerm} onChange={(event) => setSearchTerm(event.target.value)} />
        <select className="filter-select" value={category} onChange={(event) => setCategory(event.target.value)}>
          {categories.map((item) => <option key={item}>{item}</option>)}
        </select>
        <select className="filter-select" value={sortBy} onChange={(event) => setSortBy(event.target.value)}>
          <option value="name-asc">Name (A-Z)</option>
          <option value="name-desc">Name (Z-A)</option>
          <option value="price-asc">Price (Low to High)</option>
          <option value="price-desc">Price (High to Low)</option>
          {activeTypeTab === 'Pet Shop' && <option value="stock-asc">Stock (Low to High)</option>}
          {activeTypeTab === 'Pet Shop' && <option value="stock-desc">Stock (High to Low)</option>}
        </select>
        {activeTypeTab === 'Pet Shop' && (
          <select className="filter-select" value={stockLevel} onChange={(event) => setStockLevel(event.target.value)}>
            {stockLevels.map((level) => <option key={level}>{level}</option>)}
          </select>
        )}
      </div>

      <div className="category-pills">
        {petTypes.map((type) => (
          <button key={type} type="button" className={`category-pill ${selectedPetType === type ? 'active' : ''}`} onClick={() => setSelectedPetType(type)}>
            {type}
          </button>
        ))}
      </div>

      <div className="inventory-grid">
        {sortedProducts.length > 0 ? (
          sortedProducts.map((product) => (
            <div key={product.id} className="inventory-card">
              <div className="product-menu" onClick={() => setActiveDropdown(activeDropdown === product.id ? null : product.id)}>
                <span className="dots">•••</span>
                {activeDropdown === product.id && (
                  <div className="dropdown-menu">
                    <button type="button" className="dropdown-item" onClick={() => handleEditProduct(product)}>Edit</button>
                    <button type="button" className="dropdown-item delete" onClick={() => handleDeleteProduct(product.id)}>Delete</button>
                  </div>
                )}
              </div>
              {product.image && <img src={product.image} alt={product.name} className="inventory-card-image" />}
              <h3>{product.name}</h3>
              <div className="inventory-category">{product.category}</div>
              <div className="inventory-price">₱{product.price.toFixed(2)}</div>
              {product.productType === 'Pet Shop' && (
                <div className={`inventory-stock ${(product.stock || 0) <= 10 ? 'low-stock' : ''}`}>
                  {product.stock} in stock
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="no-products">
            <p>No products found matching your criteria.</p>
            <button className="add-first-btn" onClick={() => setIsAddModalOpen(true)}>Add Your First Product</button>
          </div>
        )}
      </div>

      <button className="add-product-btn" onClick={() => setIsAddModalOpen(true)}>Add Products</button>

      {isEditModalOpen && selectedProduct && (
        <div className="modal-overlay" onClick={() => setIsEditModalOpen(false)}>
          <div className="modal-content" onClick={(event) => event.stopPropagation()}>
            <div className="modal-header">
              <h2>EDIT PRODUCT</h2>
              <button className="close-btn" onClick={() => setIsEditModalOpen(false)}>×</button>
            </div>

            <form onSubmit={handleSaveEdit}>
              <div className="edit-product-container">
                <div className="edit-left-column">
                  <div className="product-image-section">
                    <h3>Product Image</h3>
                    <div className={`image-placeholder ${editForm.image ? 'has-image' : ''}`}>
                      {editForm.image ? <img src={editForm.image} alt="Product" /> : <><span>🖼️</span><span>No image selected</span></>}
                    </div>
                    <div className="file-input-container">
                      <label htmlFor="edit-image-upload" className="file-input-label">Choose File</label>
                      <input id="edit-image-upload" type="file" className="file-input" accept="image/*" onChange={(event) => handleImageUpload(event, 'edit')} />
                    </div>
                    <div className="file-name">{editForm.imageName || 'No file chosen'}</div>
                  </div>
                </div>

                <div className="edit-right-column">
                  <div className="form-row">
                    <div className="form-group">
                      <label>Product Type *</label>
                      <select name="productType" value={editForm.productType} onChange={(event) => handleInputChange(event, 'edit')} required>
                        <option>Pet Shop</option>
                        <option>Pet Menu</option>
                      </select>
                    </div>
                    <div className="form-group">
                      <label>Category *</label>
                      <select name="category" value={editForm.category} onChange={(event) => handleInputChange(event, 'edit')} required>
                        {getCategoryOptions(editForm.productType).map((item) => <option key={item}>{item}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="form-group">
                    <label>Product Name *</label>
                    <input type="text" name="name" value={editForm.name} onChange={(event) => handleInputChange(event, 'edit')} required />
                  </div>

                  <div className="two-column-grid">
                    <div className="form-group">
                      <label>Price (₱) *</label>
                      <input type="number" name="price" value={editForm.price} onChange={(event) => handleInputChange(event, 'edit')} required min="0" step="0.01" />
                    </div>
                    {editForm.productType === 'Pet Shop' && (
                      <div className="form-group">
                        <label>Stock Quantity *</label>
                        <input type="number" name="stock" value={editForm.stock} onChange={(event) => handleInputChange(event, 'edit')} required min="0" />
                      </div>
                    )}
                  </div>

                  <div className="form-group">
                    <label>Brand</label>
                    <input type="text" name="brand" value={editForm.brand} onChange={(event) => handleInputChange(event, 'edit')} />
                  </div>

                  <div className="variations-section">
                    <div className="variations-header"><h4>Variations</h4></div>
                    {editForm.variations.map((variation, index) => (
                      <div key={variation.id} className="variation-row">
                        <input type="text" placeholder="Variation Name" value={variation.name} onChange={(event) => handleVariationChange('edit', index, 'name', event.target.value)} />
                        <input type="number" placeholder="Price" value={variation.price} onChange={(event) => handleVariationChange('edit', index, 'price', event.target.value)} />
                        <button type="button" className="delete-variation-btn" onClick={() => handleDeleteVariation('edit', variation.id)}>Delete</button>
                      </div>
                    ))}
                    <button type="button" className="add-variation-btn" onClick={() => handleAddVariation('edit')}>+ Add Variation</button>
                  </div>

                  <div className="form-group">
                    <label>Description</label>
                    <textarea name="description" value={editForm.description} onChange={(event) => handleInputChange(event, 'edit')} rows="3" />
                  </div>
                </div>
              </div>

              <div className="modal-actions">
                <button type="button" className="cancel-btn" onClick={() => setIsEditModalOpen(false)}>Cancel</button>
                <button type="submit" className="save-changes-btn">Update</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isAddModalOpen && (
        <div className="modal-overlay" onClick={() => setIsAddModalOpen(false)}>
          <div className="modal-content" onClick={(event) => event.stopPropagation()}>
            <div className="modal-header">
              <h2>ADD PRODUCT</h2>
              <button className="close-btn" onClick={() => setIsAddModalOpen(false)}>×</button>
            </div>

            <form onSubmit={handleAddProduct}>
              <div className="edit-product-container">
                <div className="edit-left-column">
                  <div className="product-image-section">
                    <h3>Product Image</h3>
                    <div className={`image-placeholder ${newProduct.image ? 'has-image' : ''}`}>
                      {newProduct.image ? <img src={newProduct.image} alt="Product" /> : <><span>🖼️</span><span>No image selected</span></>}
                    </div>
                    <div className="file-input-container">
                      <label htmlFor="add-image-upload" className="file-input-label">Choose File</label>
                      <input id="add-image-upload" type="file" className="file-input" accept="image/*" onChange={(event) => handleImageUpload(event, 'add')} />
                    </div>
                    <div className="file-name">{newProduct.imageName || 'No file chosen'}</div>
                  </div>
                </div>

                <div className="edit-right-column">
                  <div className="form-row">
                    <div className="form-group">
                      <label>Product Type *</label>
                      <select name="productType" value={newProduct.productType} onChange={(event) => handleInputChange(event, 'add')} required>
                        <option>Pet Shop</option>
                        <option>Pet Menu</option>
                      </select>
                    </div>
                    <div className="form-group">
                      <label>Category *</label>
                      <select name="category" value={newProduct.category} onChange={(event) => handleInputChange(event, 'add')} required>
                        {getCategoryOptions(newProduct.productType).map((item) => <option key={item}>{item}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="form-group">
                    <label>Product Name *</label>
                    <input type="text" name="name" value={newProduct.name} onChange={(event) => handleInputChange(event, 'add')} required placeholder="Enter product name" />
                  </div>

                  <div className="two-column-grid">
                    <div className="form-group">
                      <label>Price (₱) *</label>
                      <input type="number" name="price" value={newProduct.price} onChange={(event) => handleInputChange(event, 'add')} required min="0" step="0.01" />
                    </div>
                    {newProduct.productType === 'Pet Shop' && (
                      <div className="form-group">
                        <label>Stock Quantity *</label>
                        <input type="number" name="stock" value={newProduct.stock} onChange={(event) => handleInputChange(event, 'add')} required min="0" />
                      </div>
                    )}
                  </div>

                  <div className="form-group">
                    <label>Brand</label>
                    <input type="text" name="brand" value={newProduct.brand} onChange={(event) => handleInputChange(event, 'add')} placeholder="Enter brand" />
                  </div>

                  <div className="variations-section">
                    <div className="variations-header"><h4>Variations</h4></div>
                    {newProduct.variations.map((variation, index) => (
                      <div key={variation.id} className="variation-row">
                        <input type="text" placeholder="Variation Name" value={variation.name} onChange={(event) => handleVariationChange('add', index, 'name', event.target.value)} />
                        <input type="number" placeholder="Price" value={variation.price} onChange={(event) => handleVariationChange('add', index, 'price', event.target.value)} />
                        <button type="button" className="delete-variation-btn" onClick={() => handleDeleteVariation('add', variation.id)}>Delete</button>
                      </div>
                    ))}
                    <button type="button" className="add-variation-btn" onClick={() => handleAddVariation('add')}>+ Add Variation</button>
                  </div>

                  <div className="form-group">
                    <label>Description</label>
                    <textarea name="description" value={newProduct.description} onChange={(event) => handleInputChange(event, 'add')} rows="3" />
                  </div>

                  <div className="form-group">
                    <label>Pet Type *</label>
                    <div className="pet-type-group">
                      {['Dogs', 'Cats', 'All Pets'].map((type) => (
                        <label key={type} className="pet-type-radio">
                          <input type="radio" name="petType" value={type} checked={newProduct.petType === type} onChange={(event) => handleInputChange(event, 'add')} />
                          <span>{type}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="modal-actions">
                <button type="button" className="cancel-btn" onClick={() => setIsAddModalOpen(false)}>Cancel</button>
                <button type="submit" className="save-changes-btn">Add Product</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Inventory;
